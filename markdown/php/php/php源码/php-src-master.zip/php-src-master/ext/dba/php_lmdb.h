#ifndef PHP_LMDB_H
#define PHP_LMDB_H

#if DBA_LMDB

#include "php_dba.h"

DBA_FUNCS(lmdb);

#endif

#endif
