<?php
echo "Capistrano works!";
