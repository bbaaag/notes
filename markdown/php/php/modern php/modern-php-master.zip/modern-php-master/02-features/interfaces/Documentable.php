<?php
interface Documentable
{
    public function getId();

    public function getContent();
}
