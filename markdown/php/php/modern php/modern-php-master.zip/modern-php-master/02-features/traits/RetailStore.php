<?php
class RetailStore
{
    use Geocodable;

    // Class implementation goes here
}
