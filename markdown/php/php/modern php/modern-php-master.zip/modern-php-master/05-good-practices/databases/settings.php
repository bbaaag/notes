<?php
$settings = [
    'host' => '127.0.0.1',
    'port' => '3306',
    'name' => 'books',
    'username' => 'root',
    'password' => 'jlwaxhaw',
    'charset' => 'utf8'
];
