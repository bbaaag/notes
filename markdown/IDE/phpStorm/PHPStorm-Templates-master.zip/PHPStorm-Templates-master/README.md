# PHPStorm-Templates



Current Studio Working Live Template Set.




- Windows: `<your home directory>\.<product name><version number>\config\templates`
- Linux: `~\.<product name><version number>\config\templates`
- OS X: `~/Library/Preferences/<product name><version number>/templates`




--------




Laravel Live Templates from:

<https://github.com/koomai/phpstorm-laravel-live-templates>


Bootstrap 3 Live Templates from:

<https://github.com/JasonMortonNZ/bootstrap3-phpstorm-plugin>






