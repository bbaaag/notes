﻿

$(function () {

	//alert(typeof parseInt($('div').css('width')));
	//alert(typeof $('div').width());
	//alert($('div').width());
	//alert($(window).width());
	//alert($(document).width());
	//$('div').width(500);
	//$('div').width('500px');
	//$('div').width('500pt');
	//$('div').width(function (index, width) {
	//	return width - 500 + 'px';				//虽然可以不加，会智能添加，但还是建议加上单位，更加清晰。
	//});
	
	//alert($('div').height());
													//padding, border, margin
	//alert($('div').width());					//200        200       200
	//alert($('div').innerWidth());			//400        400       400
	//alert($('div').outerWidth());			//400        600       600
	//alert($('div').outerWidth(true));	    //400        600       800
	
	//alert($('div').offset().top);
	//alert($('strong').offset().top);
	
	//alert($('div').position().top);
	//alert($('strong').offset().top);
	//alert($('strong').position().top);
	
	//alert($(window).scrollTop());
	$(window).scrollTop(300);
	
});


























