﻿

$(function () {

	//alert($('input').size());
	//alert($('input').val());
	//alert($('input').eq(1).val());		//这种写法语义不清晰，
	//alert($('input[type=password]').val());		//语义清晰一点，
	//alert($('input[name=pass]').val());
	
	//alert($('input').size());
	//alert($(':input[name=city]').size());
	//alert($(':text').size());
	//alert($(':password[name=pass]').size()); 
	//alert($(':radio').size());
	//alert($(':radio[name=sex]').eq(1).val());
	//alert($(':radio[name=sex]').last().val());
	
	//alert($('form :hidden').size());
	
	//alert($('form :enabled').size());
	//alert($('form :disabled').size());
	
	//alert($('form :checked').size());
	
	//alert($('form :selected').get(0));
	
	//alert($('form :selected').size());
	
});


























