﻿

$(function () {

	/*
	$('input').bind('click', function () {
		alert('弹窗！');
	});

	
	$('input').bind('click', fn);
	
	function fn() {
		alert('处理函数！')
	}

	
	$('input').bind('click mouseover', function () {
		alert('弹窗！');
	});

	
	$('input').bind('mouseover mouseout', function () {
		$('div').html(function (index, value) {
			return value + '1';
		});
	});

	
	$('input').bind({
		mouseover : function () {
			alert('移入');
		},
		mouseout : function () {
			alert('移出');
		}
	});

	
	$('input').bind({
		'mouseover' : function () {
			alert('移入');
		},
		'mouseout' : function () {
			alert('移出');
		}
	});

	
	$('input').bind('click mouseover', function () {
		alert('弹窗！');
	});

	
	$('input').bind('click', fn1);
	$('input').bind('click', fn2);
	
	function fn1() {
		alert('fn1');
	}
	
	function fn2() {
		alert('fn2');
	}
	
	//$('input').unbind();		//删除全部事件
	//$('input').unbind('click');	//只删除click事件
	$('input').unbind('click', fn2);  //删除click事件绑定了fn2的

	
	$('input').click(function () {
		alert('单击');
	});
	
	$('input').dblclick(function () {
		alert('双击');
	});
	
	$('input').mousedown(function () {
		alert('鼠标左键按下');
	});
	
	$('input').mouseup(function () {
		alert('鼠标左键按下弹起');
	});
	
	$(window).unload(function () {			//一般unload卸载页面新版浏览器应该是不支持的，获取要设置一个。
		alert('1');										//一般用于清理工作。
	});
	
	$(window).resize(function () {			
		alert('文档改变了');									
	});
	
	$(window).scroll(function () {			
		alert('滚动条改变了');									
	});
	$('input').select(function () {
		alert('文本选定');
	});
	
	$('input').change(function () {
		alert('文本改变');
	});
	*/

	$('form').submit(function () {
		alert('表单提交！');
	});
	
	
	
});


























