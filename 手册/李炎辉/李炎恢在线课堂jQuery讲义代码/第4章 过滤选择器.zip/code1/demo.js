﻿

$(function () {
	
	//$('li:first').css('background', '#ccc');
	//$('li:last').css('background', '#ccc');
	//$('#box li:last').css('background', '#ccc');
	//$('ul:first li:last').css('background', '#ccc');
	//$('li:not(.red)').css('background', '#ccc');
	//$('li:even').css('background', '#ccc');
	//$('li:odd').css('background', '#ccc');
	//$('li:eq(2)').css('background', '#ccc');
	//$('li:eq(-2)').css('background', '#ccc');
	//$('li:gt(3)').css('background', '#ccc');
	//$('li:lt(2)').css('background', '#ccc');
	//$('div :header').css('background', '#ccc');
	//$('input').get(0).focus();
	//$(':focus').css('background', 'red');
	
	//$('li').first().css('background', '#ccc');
	//$('li').last().css('background', '#ccc');
	//$('li').not('.red').css('background', '#ccc');
	//$('li').eq(2).css('background', '#ccc');
	//$('div:contains("ycku.com")').css('background', '#ccc');
	//$('div:empty').css('background', '#ccc').css('height','20px');
	//$('ul:has(.red)').css('background', '#ccc');
	//$('div:parent').css('background', '#ccc');
	//$('ul').has('.red').css('background', '#ccc');
	
	//alert($('li').parent().size());
	//alert($('li').parent().get(0));
	//$('li').parent().css('background', '#ccc');
	//$('li').parents().css('background', '#ccc');
	//$('li').parentsUntil('body').css('background', '#ccc');
	
	//alert($('div:hidden').size());
	//$('div:hidden').css('background', '#ccc').show(1000);
	//alert($('div:visible').size());
	
	
});


























