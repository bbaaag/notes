﻿$(function () {
	$('input').click(function () {
		alert('第一个jQuery程序！');
	});
});