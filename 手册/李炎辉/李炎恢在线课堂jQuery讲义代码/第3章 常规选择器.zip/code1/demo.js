﻿

$(function () {

	//$('#box').css('color', 'blue');			//添加一个行为，这个行为是添加样式
	
	//$('div').css('color', 'maroon');
	
	//$('.pox').css('color', 'green');
	
	//$('#box').css('color', 'red');
	
	//alert($('#box').size());
	
	//alert($('.pox').size());
	
	//alert($('div').size());
	
	//$('div').eq(1).css('color', 'red');
	
	//alert($('div').length);
	
	//$('#box > p').css('color', 'red');
	
	//$('#pox').css('color', 'red');
	
	//if (document.getElementById('pox')) {
	//	document.getElementById('pox').style.color = 'red';
	//}
	
	//很多情况下有动态DOM生成的问题，会导致执行不存在的ID选择器
	
	//$('#pox').css('color', 'red');
	
	//if ($('#pox').size() > 0) {
	//	$('#pox').css('color', 'red');
	//}
	
	//if ($('#pox').get(0)) {
	//	...
	//}
	
	//if ($('#pox')[0]) {
	//	...
	//}
	
});


























